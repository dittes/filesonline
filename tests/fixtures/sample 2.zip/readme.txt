Inside the archive.
